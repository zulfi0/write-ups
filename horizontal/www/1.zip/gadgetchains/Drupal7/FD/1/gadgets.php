<?php

class Archive_Tar
{
    public $_temp_tarname;

    public function __construct($_temp_tarname) {
        $this->_temp_tarname = $_temp_tarname;
    }

}
