<?php

class View 
{
	protected $_file;

	public function __construct($_file) {
		$this->_file = $_file;
	}
}