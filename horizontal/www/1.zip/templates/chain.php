<?php

namespace GadgetChain\{NAME};

class {CLASS_NAME} extends \{BASE_CLASS_NAME}
{
    public static $version = '';
    public static $vector = '';
    public static $author = '';

    public function generate(array $parameters)
    {

    }
}