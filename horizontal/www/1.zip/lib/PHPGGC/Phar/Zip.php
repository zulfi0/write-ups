<?php

namespace PHPGGC\Phar;


class Zip extends Format
{
	protected $format = '.zip';

	protected function update_signature()
	{
		// nothing yet :(
	}
}