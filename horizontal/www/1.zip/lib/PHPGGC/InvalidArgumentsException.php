<?php

namespace PHPGGC;

class InvalidArgumentsException extends Exception
{

}